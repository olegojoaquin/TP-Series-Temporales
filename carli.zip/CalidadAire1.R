#Attribute Information:

#0 Date (DD/MM/YYYY)
#1 Time (HH.MM.SS)
#2 True hourly averaged concentration CO in mg/m^3 (reference analyzer)
#3 PT08.S1 (tin oxide) hourly averaged sensor response (nominally CO targeted)
#4 True hourly averaged overall Non Metanic HydroCarbons concentration in microg/m^3 (reference analyzer)
#5 True hourly averaged Benzene concentration in microg/m^3 (reference analyzer)
#6 PT08.S2 (titania) hourly averaged sensor response (nominally NMHC targeted)
#7 True hourly averaged NOx concentration in ppb (reference analyzer)
#8 PT08.S3 (tungsten oxide) hourly averaged sensor response (nominally NOx targeted)
#9 True hourly averaged NO2 concentration in microg/m^3 (reference analyzer)
#10 PT08.S4 (tungsten oxide) hourly averaged sensor response (nominally NO2 targeted)
#11 PT08.S5 (indium oxide) hourly averaged sensor response (nominally O3 targeted)
#12 Temperature in Â°C
#13 Relative Humidity (%)
#14 AH Absolute Humidity

setwd ("D:/SERIES-TEMPORALES")
install.packages("forecast")
install.packages("tsibble")
install.packages("fable")
install.packages("broom")
install.packages ("feasts")
install.packages("ggplot2")
install.packages("zoo")
install.packages("imputeTS")
install.packages("openair")
install.packages("tseries")
install.packages("slider")
library(readr)
library(readxl)
library(tidyverse)
library(lubridate)
library(forecast)
library(tsibble)
library(fable)
library(broom)
library(feasts)
library(ggplot2)
library(zoo)
library(imputeTS)
library(dplyr)
library(openair)
library(tseries)
library(slider)


df <- read.csv("AirQualityUCI.csv", header = TRUE, sep=";", stringsAsFactors = FALSE)

#Unir variable fecha y hora que estan separadas
df$DateTime<-as.POSIXct(paste(df$Date,df$Time),
                        format = "%d/%m/%Y %H:%M:%S")
df$DateTime = as.POSIXct(df$DateTime)

any(is.na(df$DateTime)) 
#Borrar los registros que tienen la variable 
#temporal nula
df<-df[which(is.na(df$DateTime)==FALSE),]

#Para calcular valores de tendencia central y
#dispersion pasar coma a punto en variables 
#que estan como character 

df$CO.GT. <- as.numeric(sub(",", ".", df$CO.GT.))
df$C6H6.GT. <- as.numeric(sub(",", ".", df$C6H6.GT.))
df$T <- as.numeric(sub(",", ".", df$T))
df$RH <- as.numeric(sub(",", ".", df$RH))
df$AH <- as.numeric(sub(",", ".", df$AH))

#Reemplazar los valores -200 por NA 
df[df==-200] <- NA
# determinación del porcentaje de valores perdidos respecto del total de datos
porcentajeMiss <- function(x) {sum(is.na(x)) /length(x) *100}
# aplicar por columna
apply(df, 2, porcentajeMiss)
#Opcion 2
sapply(df,function(x) {sum(is.na(x))/dim(df)[1]})
#Opcion 3
apply(is.na(df), 2, mean)

#Gases que tienen mas del 5% de missing 
#Date          Time        CO.GT. 
#0.00000       0.00000      17.98653 
#PT08.S1.CO.      NMHC.GT.      C6H6.GT. 
#3.91151      90.23191       3.91151 
#PT08.S2.NMHC.       NOx.GT.  PT08.S3.NOx. 
#3.91151      17.51630       3.91151 
#NO2.GT.  PT08.S4.NO2.   PT08.S5.O3. 
#17.54836       3.91151       3.91151 
#T            RH            AH 
#3.91151       3.91151       3.91151 

# Los gases captados por el sensor tienen .S 

summary(df [3:15])
boxplot(df[,3:15], ylab= "Valores")


#Guardar la informacion como tsibble con la funcion
# tsibble () objeto ST en R 
df_ts <- df %>%  as_tsibble(index= DateTime)

#seleccionar los gases que se van a explorar 
Uso <-c("PT08.S1.CO.","C6H6.GT.",
        "PT08.S2.NMHC.", "PT08.S3.NOx.",
        "PT08.S4.NO2.","PT08.S5.O3.","T","RH","AH")


#Las funciones year(), month(), day(), hour(), 
#minute(), y second() nos permiten extraer ese 
#componente de la fecha.

#USADO
#Para frecuencia diaria= as.date

#Como tsibble
df_diario_ts <- df_ts %>%
  mutate(DIA= as.Date(DateTime))%>%
  index_by(DIA) %>%
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)

#Como data.frame 
df_diario <- df %>%
  mutate(DIA= as.Date(DateTime))%>%
  group_by(DIA) %>%
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)

#...............................................

#NO USADO
#Otras pruebas de agrupacion a chequear 
#Dias 1-7 (weekday)
df_diario2 <- df %>%
  mutate (week_day = wday(DateTime))
str(df1)

df_diario2 <- df_diario2 %>%
  group_by(week_day)%>%
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)
#Dias 1-7
df_diario3 <- df %>%
  mutate (df, week_day = wday(DateTime))
str(df)

df_diario3 <- group_by(df_diario3, week_day)%>%
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)

#Promedio dias 1-31 
df_diario4 <- df %>%
  group_by(day(DateTime))%>%
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)
#Promedio Dias 1-31
df_gases_dia <- df %>% 
  mutate(dia = day(DateTime)) %>% 
  group_by(dia) %>% 
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)

#Promedio dia 1-31
df_gases_dia2 <- df %>% 
  mutate(dia = format(DateTime, "%d")) %>% 
  group_by(dia) %>% 
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)
#Ver dia semana - año 
df_dia <- df1  %>% 
  mutate(año = format(DateTime, "%Y"),
         dia_semana_num = format(DateTime, "%W")) %>% 
  group_by(año, dia_semana_num) %>% 
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)

#Ver agrupar por mes- Pruebas 
df_mes <- df1 %>%
  mutate(Mes= yearmonth(DateTime))%>%
  group_by(Mes) %>% 
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)

df_mes2 <- df1  %>% 
  mutate(año = format(DateTime, "%Y"),
         mes = format(DateTime, "%m")) %>% 
  group_by(año, mes) %>% 
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)
df_se <- df1 %>%
  mutate(Semana= yearweek(DateTime))%>%
  group_by(Semana) %>% 
  summarise_at(c("PT08.S1.CO.","C6H6.GT.",
                 "PT08.S2.NMHC.", "PT08.S3.NOx.",
                 "PT08.S4.NO2.","PT08.S5.O3.",
                 "T","RH","AH"), mean, na.rm=TRUE)

#...........................................

#Analisis exploratorio: Grafico de linea y boxplot 
#para todas las variables  
boxplot(df_diario[,2:10], ylab= "Valores")
#Boxplot solo con los gases
boxplot(df_diario[,3:7], ylab= "Valores")


#Graficos por gases - autoplot con tipo tsibble
#Medicion horaria 
autoplot(df_ts,PT08.S1.CO.) +
  labs(title = "Oxido de estaño",
       y = "PT08.S1.CO.")
autoplot(df_ts,C6H6.GT.) +
  labs(title = "C6H6",
       y = "C6H6")
autoplot(df_ts,PT08.S2.NMHC.) +
  labs(title = "NMHC",
       y = "NMHC")
autoplot(df_ts,PT08.S3.NOx.) +
  labs(title = "NOx",
       y = "NoX")
autoplot(df_ts,PT08.S4.NO2.) +
  labs(title = "NO2",
       y = "No2")
autoplot(df_ts,PT08.S5.O3.) +
  labs(title = "O3",
       y = "O3")
autoplot(df_ts,T) +
  labs(title = "T",
       y = "T")
autoplot(df_ts,RH) +
  labs(title = "RH",
       y = "RH")
autoplot(df_ts,AH) +
  labs(title = "AH",
       y = "AH")


#Graficos Gases 
#Promedio diario 

autoplot(df_diario_ts,PT08.S1.CO.) +
  labs(title = "Oxido de estaño",
       y = "PT08.S1.CO.")
autoplot(df_diario_ts,C6H6.GT.) +
  labs(title = "C6H6",
       y = "C6H6")
autoplot(df_diario_ts,PT08.S2.NMHC.) +
  labs(title = "NMHC",
       y = "NMHC")
autoplot(df_diario_ts,PT08.S3.NOx.) +
  labs(title = "NOx",
       y = "NoX")
autoplot(df_diario_ts,PT08.S4.NO2.) +
  labs(title = "NO2",
       y = "No2")
autoplot(df_diario_ts,PT08.S5.O3.) +
  labs(title = "O3",
       y = "O3")
autoplot(df_diario_ts,T) +
  labs(title = "T",
       y = "T")
autoplot(df_diario_ts,RH) +
  labs(title = "RH",
       y = "RH")
autoplot(df_diario_ts,AH) +
  labs(title = "AH",
       y = "AH")

#Grafico de los gases que se van a analizar 
par(mfrow= c(3,3))
plot(df_ts$PT08.S1.CO.,type="l")
plot(df_ts$C6H6.GT.,type="l")
plot(df_ts$PT08.S2.NMHC.,type="l")
plot(df_ts$PT08.S3.NOx.,type="l")
plot(df_ts$PT08.S4.NO2.,type="l")
plot(df_ts$PT08.S5.O3.,type="l")

#Promedio de Gases por dia 
par(mfrow= c(3,3))
plot(df_diario_ts$PT08.S1.CO.,type="l")
plot(df_diario_ts$C6H6.GT.,type="l")
plot(df_diario_ts$PT08.S2.NMHC.,type="l")
plot(df_diario_ts$PT08.S3.NOx.,type="l")
plot(df_diario_ts$PT08.S4.NO2.,type="l")
plot(df_diario_ts$PT08.S5.O3.,type="l")

# las variables que quedan tienen valores NA (missing)
#Hay que estimar (imputar) esos datos (reemplazo
#con valores predichos desde los datos presentes) 

#Imputacion por interpolacion (Ver-prueba)
df_inter <- na.interpolation(df1, option="spline")
par(mfrow= c(1,2))
plot(df1$PT08.S1.CO.,type="l")
plot(df$PT08.S1.CO.,type="l")
summary(df_inter$PT08.S1.CO.)

#Imputacion por MA
#pasa que para comparar los filtros tienen que ser 
#con el promedio del dia 
#Hacer con 3-5-7-9
#Prueba con serie AH - k=3 

df_ts$AH_imp <- na_ma(df_ts$AH, k=3, weighting = "exponential")
df_movil <- df_ts %>%
  mutate("3-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_movil %>%
  autoplot(AH_imp) +
  geom_line(aes(y = `3-MA`), colour = "red") +
  labs(y = "Valor AH",
       title = "Prueba AH") +
  guides(colour = guide_legend(title = "series"))

class("3-MA")
as.numeric(df_movil$`3-MA`)
class(df_movil$`3-MA`)

df_diario_ts$AH_imp <- na_ma(df_diario_ts$AH, k=3, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("3-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_diario_ts %>%
  autoplot(AH_imp) +
  geom_line(aes(y = `3-MA`), colour = "red") +
  labs(y = "Valor AH",
       title = "Prueba AH") +
  guides(colour = guide_legend(title = "series"))

#Prueba con serie AH - k=5

df_ts$AH_imp5 <- na_ma(df_ts$AH, k=5, weighting = "exponential")
df_movil <- df_ts %>%
  mutate("5-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 2, .after = 2, .complete = TRUE))

df_movil %>%
  autoplot(AH_imp5) +
  geom_line(aes(y = `5-MA`), colour = "blue") +
  labs(y = "Valor AH5",
       title = "Prueba AH5") +
  guides(colour = guide_legend(title = "series"))


df_diario_ts$AH_imp5 <- na_ma(df_diario_ts$AH, k=5, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("5-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 2, .after = 2, .complete = TRUE))

df_diario_ts %>%
  autoplot(AH_imp5) +
  geom_line(aes(y = `5-MA`), colour = "blue") +
  labs(y = "Valor AH5",
       title = "Prueba AH5") +
  guides(colour = guide_legend(title = "series"))


#Prueba con serie AH - k=7

df_ts$AH_imp7 <- na_ma(df_ts$AH, k=7, weighting = "exponential")
df_movil <- df_ts %>%
  mutate("7-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 3, .after = 3, .complete = TRUE))

df_movil %>%
  autoplot(AH_imp7) +
  geom_line(aes(y = `7-MA`), colour = "yellow") +
  labs(y = "Valor AH7",
       title = "Prueba AH7") +
  guides(colour = guide_legend(title = "series"))



df_diario_ts$AH_imp7 <- na_ma(df_diario_ts$AH, k=7, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("7-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 3, .after = 3, .complete = TRUE))

df_diario_ts %>%
  autoplot(AH_imp7) +
  geom_line(aes(y = `7-MA`), colour = "yellow") +
  labs(y = "Valor AH7",
       title = "Prueba AH7") +
  guides(colour = guide_legend(title = "series"))


#Prueba con serie AH - k=9
df_ts$AH_imp9 <- na_ma(df_ts$AH, k=9, weighting = "exponential")
df_movil <- df_ts %>%
  mutate("9-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 4, .after = 4, .complete = TRUE))

df_movil %>%
  autoplot(AH_imp9) +
  geom_line(aes(y = `9-MA`), colour = "pink") +
  labs(y = "Valor AH9",
       title = "Prueba AH9") +
  guides(colour = guide_legend(title = "series"))



df_diario_ts$AH_imp9 <- na_ma(df_diario_ts$AH, k=9, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("9-MA" = slider::slide_dbl(AH_imp, mean,
                                    .before = 4, .after = 4, .complete = TRUE))

df_diario_ts %>%
  autoplot(AH_imp9) +
  geom_line(aes(y = `9-MA`), colour = "pink") +
  labs(y = "Valor AH9",
       title = "Prueba AH9") +
  guides(colour = guide_legend(title = "series"))


#USO Series con 3-MA 

#Grafico Serie AH 
df_diario_ts %>% ACF(AH_imp)
df_diario_ts %>%
  ACF(AH_imp) %>%
  autoplot() + labs(title="ACF-AH_imp")

#Grafico Serie CO 

df_diario_ts$PT.08.S1.CO._imp <- na_ma(df_diario_ts$PT08.S1.CO., k=3, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("3-MA" = slider::slide_dbl(PT.08.S1.CO._imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_diario_ts %>% ACF(PT.08.S1.CO._imp )
df_diario_ts %>%
  ACF(PT.08.S1.CO._imp) %>%
  autoplot() + labs(title="ACF-CO_imp")


#Grafico Serie NMHC

df_diario_ts$PT08.S2.NMHC._imp <- na_ma(df_diario_ts$PT08.S2.NMHC., k=3, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("3-MA" = slider::slide_dbl(PT08.S2.NMHC._imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_diario_ts %>% ACF(PT08.S2.NMHC._imp )
df_diario_ts %>%
  ACF(PT08.S2.NMHC._imp) %>%
  autoplot() + labs(title="ACF-NMHC_imp")

#Grafico Serie NOx

df_diario_ts$PT08.S3.NOx._imp <- na_ma(df_diario_ts$PT08.S3.NOx., k=3, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("3-MA" = slider::slide_dbl(PT08.S3.NOx._imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_diario_ts %>% ACF(PT08.S3.NOx._imp )
df_diario_ts %>%
  ACF(PT08.S3.NOx._imp) %>%
  autoplot() + labs(title="ACF-NOx_imp")

# Grafico Serie NO2

df_diario_ts$PT08.S4.NO2._imp <- na_ma(df_diario_ts$PT08.S4.NO2., k=3, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("3-MA" = slider::slide_dbl(PT08.S4.NO2._imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_diario_ts %>% ACF(PT08.S4.NO2._imp )
df_diario_ts %>%
  ACF(PT08.S4.NO2._imp) %>%
  autoplot() + labs(title="ACF-NO2_imp")

#Grafico serie 03

df_diario_ts$PT08.S5.O3._imp <- na_ma(df_diario_ts$PT08.S5.O3., k=3, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("3-MA" = slider::slide_dbl(PT08.S5.O3._imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_diario_ts %>% ACF(PT08.S5.O3._imp )
df_diario_ts %>%
  ACF(PT08.S5.O3._imp) %>%
  autoplot() + labs(title="ACF-O3_imp")

#Grafico Serie temperatura

df_diario_ts$T_imp <- na_ma(df_diario_ts$T, k=3, weighting = "exponential")
df_diario_ts <- df_diario_ts %>%
  mutate("3-MA" = slider::slide_dbl(T_imp, mean,
                                    .before = 2, .after = 0, .complete = TRUE))

df_diario_ts %>% ACF(T_imp )
df_diario_ts %>%
  ACF(T_imp) %>%
  autoplot() + labs(title="ACF-T_imp")

